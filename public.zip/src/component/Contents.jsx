import React from 'react'

const Contents = () => {
  return (
    <div>Contents</div>
  )
}

export default Contents
import React from 'react'
import { Container } from 'reactstrap';

const MiddleNav = () => {
  return (
  <Container>
    <Row>
      <Col>로고</Col>
      <Col>검색창</Col>
      <Col>
        <a href="/save">장바구니</a>
        <a href="/">장바구니</a>
        <a href="/save">장바구니</a>
      </Col>
    </Row>
  </Container>
  )
}

export default MiddleNav